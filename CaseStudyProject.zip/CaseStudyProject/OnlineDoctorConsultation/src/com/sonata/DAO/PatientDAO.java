package com.sonata.DAO;

public interface PatientDAO {
	public int insertPatient(Object obj);	
	public int updatePatient(Object obj,int id);
}
